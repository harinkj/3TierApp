export class Application {

    id: string;
    appName: string;
    appDescription: string;
    stakeHolder: string;
  }