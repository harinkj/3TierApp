package com.carefirst.coe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationOnboardingServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationOnboardingServicesApplication.class, args);
	}
}
