import { ApplicationService } from './application.service';
import { Application } from './../models/application.model';

import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'

@Component({
  selector: 'app-applications',
  templateUrl: './applications.component.html',
  styleUrls: ['./applications.component.css']
})
export class ApplicationsComponent implements OnInit {

  applications:Application[];

  constructor(private router:Router, private appService:ApplicationService) { }

  ngOnInit() {

    this.appService.getApplications()
    .subscribe(
      data =>{
        this.applications=data;
      }

    );
  }

  deleteApplication(application:Application)
  {
    this.appService.deleteApplication(application).subscribe(
      data=>{
        this.applications=this.applications.filter(a=> a!==application);
      }
    );
  }

}
