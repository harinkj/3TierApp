import { Application } from './../models/application.model';

import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

@Injectable()
export class ApplicationService
{
    constructor(private http:HttpClient)
    {
        
    }

    //private applUrl='http://localhost:8080/api'
    private applUrl='/api'

    /**
     * getUsers
     */
    public getApplications() {
        return this.http.get<Application[]>(this.applUrl);
    }

    /**
     * deleteUser
     */
    public deleteApplication(user) {

        return this.http.delete(this.applUrl+"/"+user.id);
        
    }

    /**
     * createUser
     */
    public createApplication(user) {
        return this.http.post<Application>(this.applUrl,user);
    }
}