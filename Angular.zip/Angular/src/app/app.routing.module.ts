import { AddApplicationComponent } from './applications/add-application.component';
import { ApplicationsComponent } from './applications/applications.component';
import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
const routes:Routes=[
    {path:'apps',component:ApplicationsComponent},
    {path:'add',component:AddApplicationComponent}
]
@NgModule(
{
    imports: [
        RouterModule.forRoot(routes)
      ],
      exports: [
        RouterModule
      ],
      declarations: []
    
}
)
export class AppRoutingModule
{

}