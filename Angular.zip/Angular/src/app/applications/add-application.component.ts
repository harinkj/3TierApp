import { Router } from '@angular/router';

import { Component } from "@angular/core";
import { Application } from "../models/application.model";
import { ApplicationService } from './application.service';

@Component(
    {
        templateUrl:'./add-application.component.html'
    }
)

export class AddApplicationComponent
{
application:Application=new Application();

constructor(private router:Router, private appService :ApplicationService)
{

}

createApplication(): void{
    this.appService.createApplication(this.application)
    .subscribe(data=>{
        alert("Application Created Successfully!!");
    })
}
}